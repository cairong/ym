console.log('hello elecV2P, nice to meet you!')
console.log('current version', __version)
console.log('Project: https://github.com/elecV2/elecV2P')
console.log('Docs: https://github.com/elecV2/elecV2P-dei')

console.log('telegram channel: https://t.me/elecV2')

$done('elecV2P test done')